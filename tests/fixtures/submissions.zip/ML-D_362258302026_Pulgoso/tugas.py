import os
import CRUD as crud_module

def clear_terminal(os_type: str):
    match os_type:
        case "posix":
            os.system("clear")
        case "nt":
            os.system("cls")

def show_header():
    print("SELAMAT DATANG DI APLIKASI")
    print("MANAJEMEN DATABASE PERPUSTAKAAN")
    print("=" * 25)

if __name__ == "__main__":
    os_type = os.name

    clear_terminal(os_type)
    show_header()

    # inisialisasi database
    crud_module.init_console()

    while True:
        clear_terminal(os_type)
        show_header()

        print("1. Read Data")
        print("2. Create Data")
        print("3. Update Data")
        print("4. Delete Data\n")

        menu_choice = input("Masukkan opsi: ")

        match menu_choice:
            case "1": crud_module.read_console()
            case "2": crud_module.create_console()
            case "3": crud_module.update_console()
            case "4": crud_module.delete_console()

        finish = input("Selesai (y/n)? ")
        if finish.lower() == "y":
            break

    print("Program selesai, terima kasih.")